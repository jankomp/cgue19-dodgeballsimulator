dodgeballsimulator

Doris Maria Rhomberg (01649642) - E 033 532	 	
Jan Kompatscher (01527584) - E 033 532

tested on NVIDIA